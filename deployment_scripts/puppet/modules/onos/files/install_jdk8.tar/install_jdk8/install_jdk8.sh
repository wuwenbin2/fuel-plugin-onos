#!/bin/bash

mkdir /usr/lib/jvm/
tar -xzf /opt/jdk-8u51-linux-x64.tar.gz -C /usr/lib/jvm/
mv /usr/lib/jvm/jdk1.8.0_51 /usr/lib/jvm/java-8-oracle
cp -f /opt/install_jdk8/jdk* /etc/profile.d/

export J2SDKDIR=/usr/lib/jvm/java-8-oracle;
export J2REDIR=/usr/lib/jvm/java-8-oracle/jre;
export PATH=$PATH:/usr/lib/jvm/java-8-oracle/bin:/usr/lib/jvm/java-8-oracle/db/bin:/usr/lib/jvm/java-8-oracle/jre/bin;
export JAVA_HOME=/usr/lib/jvm/java-8-oracle;
export DERBY_HOME=/usr/lib/jvm/java-8-oracle/db;
